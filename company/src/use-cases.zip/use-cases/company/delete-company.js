module.exports = function makeDeleteCompany({
    deleteEmployeeByCompanyId,
    deleteCompanyDb,
    validationError,
    Joi,
})
{
    return async function deleteCompany({ id })
    {
        const {error} = validateInput({ id });
        if(error)
            throw new validationError(error.message);

        let companyId = await deleteCompanyDb({ id });

        await deleteEmployeeByCompanyId({ id })
            
        return companyId;
    }
    function validateInput({ id })
    {
        const schema = Joi.object({
           id: Joi.string().required(),
        })
        return schema.validate({ id })
    }
}