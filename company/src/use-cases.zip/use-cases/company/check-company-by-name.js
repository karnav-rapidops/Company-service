module.exports = function makecheckCompanyByName({
    getCompanyByNameDb,
    validationError,
    Joi,
})
{
    return async function checkCompanyByName({ name })
    {
        const {error} = validateCheckCompanyByName({ name })
        if(error)
            throw new validationError(error.message);

        let companyListLength = await getCompanyByNameDb({ name });

        return companyListLength;
    }
    function validateCheckCompanyByName({ name })
    {
        const schema = Joi.object({
            name: Joi.string().min(1).max(15).required(),
        })
        return schema.validate({ name })    
    }
}