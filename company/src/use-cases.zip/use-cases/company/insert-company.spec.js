const {Given, When, Then, After} = require('@cucumber/cucumber');
const exception = require('../../exceptions')
const expect = require('chai').expect;
const sinon = require('sinon');
const Joi = require('joi');

// Import use-case maker function
const makeInsertCompany = require('./insert-company');
const sandbox = sinon.createSandbox();

// companyDb object for function which will be stub
const companyDb = {
    insertCompanyDb: ()=>{
    },
    checkCompanyByName: ()=>{

    }
}

const insertCompanyDbStub = sandbox.stub(companyDb, 'insertCompanyDb')

insertCompanyDbStub.callsFake((args)=>{
    
  console.log("insertCompanyDbStub: ", args);  
  expect(args).deep.equal({ 
    cname: this.cname, 
    email: this.email, 
    address: this.address, 
    estyear: this.estyear, 
    type: this.type, 
})

  return '123';

})

const checkCompanyByNameStub = sandbox.stub(companyDb, 'checkCompanyByName');
checkCompanyByNameStub.callsFake((args)=>{
    expect(args).deep.equal({
        cname: this.cname,
    })

    return "abc";
})


Given ("Company details name: {string}, email: {string} , address: {string} , estyear: {string} , type: {string} to create new company", (cname, email, address, estyear, type)=>{
    this.cname = cname || undefined;
    this.email =  email || undefined;
    this.address = address || undefined;
    this.estyear = estyear || undefined;
    this.type = type || undefined;
})

When ('Try to create new company', async () => {
    const insertCompany = makeInsertCompany({
        insertCompanyDb: companyDb.insertCompanyDb,
        validationError: exception.validationError,
        checkCompanyByName: companyDb.checkCompanyByName,
        Joi,
    }); 
  
    try {
    console.log("in try: ", {
        cname: this.cname,
        email: this.email,
        address: this.address,
        estyear: this.estyear,
        type: this.type
      })
      this.result = await insertCompany({
        cname: this.cname,
        email: this.email,
        address: this.address,
        estyear: this.estyear,
        type: this.type
      });  
    } 
    catch (e) {
      this.error = {
        name: e.name,
        message: e.message,
      };
    }
});

Then('It will throw error: {string} with message: "{string}" while creating new company', (error, message) => {
    expect(this.error).deep.equal({
      name: error,
      message,
    });
  });

Then('It will create new company with details: "{string}"', (newCompanyDetails) => {
  expect(this.result).deep.equal(newCompanyDetails)
});
