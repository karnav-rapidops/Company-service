module.exports = function makeGetAllCompany({
    getAllCompanyDb,
})
{
    return async function getAllCompnay()
    {

        let companyList = await getAllCompanyDb();

        return companyList;
    }

}